-- trigger on insert empleado
create or replace function empleado_trigger_fn() returns trigger as
$$
begin	
	if new.id_Sucursal = 1 then
		insert into EmpleadoSucursal1 values(new.*);
	elseif new.id_Sucursal = 2 then
		insert into EmpleadoSucursal2 values(new.*);
	elseif new.id_Sucursal = 3 then
		insert into EmpleadoSucursal3 values(new.*);
	elseif new.id_Sucursal = 4 then
		insert into EmpleadoSucursal4 values(new.*);
	end if;
	
    return null;
end
$$
language plpgsql;

drop trigger if exists empleado_trigger on Empleado;  
create trigger empleado_trigger before insert on Empleado for each row execute procedure empleado_trigger_fn();

-- trigger on insert Cliente
create or replace function cliente_trigger_fn() returns trigger as
$$
begin	
	if new.id_Sucursal = 1 then
		insert into ClienteSucursal1 values(new.*);
	elseif new.id_Sucursal = 2 then
		insert into ClienteSucursal2 values(new.*);
	elseif new.id_Sucursal = 3 then
		insert into ClienteSucursal3 values(new.*);
	elseif new.id_Sucursal = 4 then
		insert into ClienteSucursal4 values(new.*);
	end if;
	
    return null;
end
$$
language plpgsql;

drop trigger if exists cliente_trigger on Cliente;  
create trigger cliente_trigger before insert on Cliente for each row execute procedure cliente_trigger_fn();

-- trigger on insert Mesa
create or replace function mesa_trigger_fn() returns trigger as
$$
begin
	if new.id_Sucursal = 1 then
		insert into MesaSucursal1 values(new.*);
	elseif new.id_Sucursal = 2 then
		insert into MesaSucursal2 values(new.*);
	elseif new.id_Sucursal = 3 then
		insert into MesaSucursal3 values(new.*);
	elseif new.id_sucursal = 4 then
		insert into MesaSucursal4 values(new.*);
	end if;
	
    return null;
end
$$
language plpgsql;

drop trigger if exists mesa_trigger on Mesa;  
create trigger mesa_trigger before insert on Mesa for each row execute procedure mesa_trigger_fn();

-- trigger on insert Pedido
create or replace function pedido_trigger_fn() returns trigger as
$$
begin
	if new.id_Sucursal_Mesa = 1 then
		insert into PedidoSucursal1 values(new.*);
	elseif new.id_Sucursal_Mesa = 2 then
		insert into PedidoSucursal2 values(new.*);
	elseif new.id_Sucursal_Mesa = 3 then
		insert into PedidoSucursal3 values(new.*);
	elseif new.id_Sucursal_Mesa = 4 then
		insert into PedidoSucursal4 values(new.*);
	end if;
	
    return null;
end
$$
language plpgsql;

drop trigger if exists pedido_trigger on Pedido;  
create trigger pedido_trigger before insert on Pedido for each row execute procedure pedido_trigger_fn();

-- trigger on insert LineaPedido
create or replace function lineapedido_trigger_fn() returns trigger as
$$
declare
	pedido Pedido%rowtype;
begin
	select * into pedido from Pedido where id=new.id_Pedido;

	if pedido.id_Sucursal_Mesa = 1 then
		insert into LineaPedidoSucursal1 values(new.*);
	elseif pedido.id_Sucursal_Mesa = 2 then
		insert into LineaPedidoSucursal2 values(new.*);
	elseif pedido.id_Sucursal_Mesa = 3 then
		insert into LineaPedidoSucursal3 values(new.*);
	elseif pedido.id_Sucursal_Mesa = 4 then
		insert into LineaPedidoSucursal4 values(new.*);
	end if;
	
    return null;
end
$$
language plpgsql;

drop trigger if exists lineapedido_trigger on LineaPedido;  
create trigger lineapedido_trigger before insert on LineaPedido for each row execute procedure lineapedido_trigger_fn();

-- trigger on insert Producto
create or replace function producto_trigger_fn() returns trigger as
$$
begin
	if new.id_Sucursal = 1 then
		insert into ProductoSucursal1 values(new.*);
	elseif new.id_Sucursal = 2 then
		insert into ProductoSucursal2 values(new.*);
	elseif new.id_Sucursal = 3 then
		insert into ProductoSucursal3 values(new.*);
	elseif new.id_sucursal = 4 then
		insert into ProductoSucursal4 values(new.*);
	end if;
	
    return null;
end
$$
language plpgsql;

drop trigger if exists producto_trigger on Producto;  
create trigger producto_trigger before insert on Producto for each row execute procedure producto_trigger_fn();


-- trigger on insert Reservacion
create or replace function reservacion_trigger_fn() returns trigger as
$$
begin
	if new.id_Sucursal_Mesa = 1 then
		insert into ReservacionSucursal1 values(new.*);
	elseif new.id_Sucursal_Mesa = 2 then
		insert into ReservacionSucursal2 values(new.*);
	elseif new.id_Sucursal_Mesa = 3 then
		insert into ReservacionSucursal3 values(new.*);
	elseif new.id_Sucursal_Mesa = 4 then
		insert into ReservacionSucursal4 values(new.*);
	end if;
	
    return null;
end
$$
language plpgsql;

drop trigger if exists reservacion_trigger on Reservacion;  
create trigger reservacion_trigger before insert on Reservacion for each row execute procedure reservacion_trigger_fn();

-- trigger on insert Horario
create or replace function horario_trigger_fn() returns trigger as
$$
begin
	if new.id_Sucursal = 1 then
		insert into HorarioSucursal1 values(new.*);
	elseif new.id_Sucursal = 2 then
		insert into HorarioSucursal2 values(new.*);
	elseif new.id_Sucursal = 3 then
		insert into HorarioSucursal3 values(new.*);
	elseif new.id_Sucursal = 4 then
		insert into HorarioSucursal4 values(new.*);
	end if;
	
    return null;
end
$$
language plpgsql;

drop trigger if exists horario_trigger on Horario;  
create trigger horario_trigger before insert on Horario for each row execute procedure horario_trigger_fn();

-- trigger on insert Horario
create or replace function empleado_horario_trigger_fn() returns trigger as
$$
declare
	empleado Empleado%rowtype;
begin
	select * into empleado from Empleado where id=new.id_Empleado;
	if empleado.id_Sucursal = 1 then
		insert into Empleado_HorarioSucursal1 values(new.*);
	elseif empleado.id_Sucursal = 2 then
		insert into Empleado_HorarioSucursal2 values(new.*);
	elseif empleado.id_Sucursal = 3 then
		insert into Empleado_HorarioSucursal3 values(new.*);
	elseif empleado.id_Sucursal = 4 then
		insert into Empleado_HorarioSucursal4 values(new.*);
	end if;
	
    return null;
end
$$
language plpgsql;

drop trigger if exists empleado_horario_trigger on Empleado_Horario;  
create trigger empleado_horario_trigger before insert on Empleado_Horario for each row execute procedure empleado_horario_trigger_fn();

-- trigger on insert Persona
create or replace function persona_trigger_fn() returns trigger as
$$
declare
	letraApellido char;
	apellido text;
begin
	apellido := new.apellPaterno;
	letraApellido := UPPER(substring(apellido,1,1));
	if letraApellido >= 'A' and letraApellido <= 'F' then
		insert into PersonaAF values(new.*);
	elseif letraApellido >= 'G' and letraApellido <= 'L' then
		insert into PersonaGL values(new.*);
	elseif letraApellido >= 'M' and letraApellido <= 'S' then
		insert into PersonaMS values(new.*);
	elseif letraApellido >= 'T' and letraApellido <= 'Z' then
		insert into PersonaTZ values(new.*);
	end if;
	
	return null;
end
$$
language plpgsql;

drop trigger if exists persona_trigger on Persona;
create trigger persona_trigger before insert on Persona for each row execute procedure persona_trigger_fn();

-- trigger on insert Persona
create or replace function cuenta_trigger_fn() returns trigger as
$$
declare
	persona Persona%rowtype;	
	letraApellido char;
	apellido text;
begin
	select * into persona from Persona where id = new.id_Persona;
	apellido := persona.apellPaterno;
	letraApellido := UPPER(substring(apellido,1,1));
	if letraApellido >= 'A' and letraApellido <= 'F' then
		insert into CuentaAF values(new.*);
	elseif letraApellido >= 'G' and letraApellido <= 'L' then
		insert into CuentaGL values(new.*);
	elseif letraApellido >= 'M' and letraApellido <= 'S' then
		insert into CuentaMS values(new.*);
	elseif letraApellido >= 'T' and letraApellido <= 'Z' then
		insert into CuentaTZ values(new.*);
	end if;
	
	return null;
end
$$
language plpgsql;

drop trigger if exists cuenta_trigger on Cuenta;
create trigger cuenta_trigger before insert on Cuenta for each row execute procedure cuenta_trigger_fn();

-- trigger on insert Persona
create or replace function telefono_trigger_fn() returns trigger as
$$
declare
	persona Persona%rowtype;	
	letraApellido char;
	apellido text;
begin
	select * into persona from Persona where id = new.id_Persona;
	apellido := persona.apellPaterno;
	letraApellido := UPPER(substring(apellido,1,1));
	if letraApellido >= 'A' and letraApellido <= 'F' then
		insert into TelefonoAF values(new.*);
	elseif letraApellido >= 'G' and letraApellido <= 'L' then
		insert into TelefonoGL values(new.*);
	elseif letraApellido >= 'M' and letraApellido <= 'S' then
		insert into TelefonoMS values(new.*);
	elseif letraApellido >= 'T' and letraApellido <= 'Z' then
		insert into TelefonoTZ values(new.*);
	end if;
	
	return null;
end
$$
language plpgsql;

drop trigger if exists telefono_trigger on Telefono;
create trigger telefono_trigger before insert on Telefono for each row execute procedure telefono_trigger_fn();

-- trigger on insert Persona
create or replace function documento_trigger_fn() returns trigger as
$$
declare
	persona Persona%rowtype;	
	letraApellido char;
	apellido text;
begin
	select * into persona from Persona where id = new.id_Persona;
	apellido := persona.apellPaterno;
	letraApellido := UPPER(substring(apellido,1,1));
	if letraApellido >= 'A' and letraApellido <= 'F' then
		insert into DocumentoAF values(new.*);
	elseif letraApellido >= 'G' and letraApellido <= 'L' then
		insert into DocumentoGL values(new.*);
	elseif letraApellido >= 'M' and letraApellido <= 'S' then
		insert into DocumentoMS values(new.*);
	elseif letraApellido >= 'T' and letraApellido <= 'Z' then
		insert into DocumentoTZ values(new.*);
	end if;
	
	return null;
end
$$
language plpgsql;

drop trigger if exists documento_trigger on Documento;
create trigger documento_trigger before insert on Documento for each row execute procedure documento_trigger_fn();


-- trigger on insert Direccion 
create or replace function direccion_trigger_fn() returns trigger as
$$
begin
	insert into DireccionFragmento values(new.*);
	return null;
end
$$
language plpgsql;

drop trigger if exists direccion_trigger on Direccion;
create trigger direccion_trigger before insert on Direccion for each row execute procedure direccion_trigger_fn();

-- trigger on insert RolEmpleado
create or replace function rolempleado_trigger_fn() returns trigger as
$$
begin
	insert into RolEmpleadoFragmento values(new.*);
	return null;
end
$$
language plpgsql;

drop trigger if exists rolempleado_trigger on RolEmpleado;
create trigger rolempleado_trigger before insert on RolEmpleado for each row execute procedure rolempleado_trigger_fn();

-- trigger on insert Sucursal
create or replace function sucursal_trigger_fn() returns trigger as
$$
begin
	insert into SucursalFragmento values(new.*);
	return null;
end
$$
language plpgsql;

drop trigger if exists sucursal_trigger on Sucursal;
create trigger sucursal_trigger before insert on Sucursal for each row execute procedure sucursal_trigger_fn();

-- trigger on insert TipoDocumento
create or replace function tipodocumento_trigger_fn() returns trigger as
$$
begin
	insert into TipoDocumentoFragmento values(new.*);
	return null;
end
$$
language plpgsql;

drop trigger if exists tipodocumento_trigger on TipoDocumento;
create trigger tipodocumento_trigger before insert on TipoDocumento for each row execute procedure tipodocumento_trigger_fn();

-- trigger on insert RolCuenta
create or replace function rolcuenta_trigger_fn() returns trigger as
$$
begin
	insert into RolCuentaFragmento values(new.*);
	return null;
end
$$
language plpgsql;

drop trigger if exists rolcuenta_trigger on RolCuenta;
create trigger rolcuenta_trigger before insert on RolCuenta for each row execute procedure rolcuenta_trigger_fn();

-- trigger on insert Categoria
create or replace function categoria_trigger_fn() returns trigger as
$$
begin
	insert into CategoriaFragmento values(new.*);
	return null;
end
$$
language plpgsql;

drop trigger if exists categoria_trigger on Categoria;
create trigger categoria_trigger before insert on Categoria for each row execute procedure categoria_trigger_fn();

-- trigger on insert ValeDescuento
create or replace function valedescuento_trigger_fn() returns trigger as
$$
begin
	insert into ValeDescuentoFragmento values(new.*);
	return null;
end
$$
language plpgsql;

drop trigger if exists valedescuento_trigger on ValeDescuento;
create trigger valedescuento_trigger before insert on ValeDescuento for each row execute procedure valedescuento_trigger_fn();
