
-- ---
-- Table 'Producto'
-- 
-- ---

DROP TABLE IF EXISTS ProductoSucursal4;
		
CREATE TABLE ProductoSucursal4 (
  id SERIAL,
  nombre VARCHAR(50) ,
  precio FLOAT ,
  descrip TEXT ,
  disponible BOOL ,
  id_Categoria INT ,
  id_Sucursal INT ,
  imagen TEXT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Pedido'
-- 
-- ---

DROP TABLE IF EXISTS PedidoSucursal4;
		
CREATE TABLE PedidoSucursal4 (
  id SERIAL,
  fecha DATE ,
  hora TIME ,
  id_Empleado INT ,
  id_Persona INT ,
  consumoTotal FLOAT ,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  estado VARCHAR(50),
  PRIMARY KEY (id)
);

-- ---
-- Table 'LineaPedido'
-- 
-- ---
--
DROP TABLE IF EXISTS LineaPedidoSucursal4;
		
CREATE TABLE LineaPedidoSucursal4 (
  id SERIAL,
  id_Producto INT,
  id_Pedido INT,
  cantidad INT,
  PRIMARY KEY (id, id_Pedido)
);

-- ---
-- Table 'Empleado'
-- 
-- ---

DROP TABLE IF EXISTS EmpleadoSucursal4;
		
CREATE TABLE EmpleadoSucursal4 (
  id SERIAL,
  id_Persona INT ,
  horasSemana INT ,
  id_RolEmpleado INT ,
  id_Sucursal INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Cliente'
-- 
-- ---
DROP TABLE IF EXISTS ClienteSucursal4;

CREATE TABLE ClienteSucursal4 (
  id SERIAL,
  id_Persona int,
  id_Sucursal int,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Mesa'
-- 
-- ---

DROP TABLE IF EXISTS MesaSucursal4;
		
CREATE TABLE MesaSucursal4 (
  id_Sucursal SERIAL,
  id INT,
  capacidad INT ,
  PRIMARY KEY (id, id_Sucursal)
);

-- ---
-- Table 'Reservacion'
-- 
-- ---

DROP TABLE IF EXISTS ReservacionSucursal4;
		
CREATE TABLE ReservacionSucursal4 (
  id SERIAL,
  fecha DATE,
  hora TIME,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  id_Persona INT ,
  PRIMARY KEY (id),
  UNIQUE (hora, fecha, id_Mesa, id_Sucursal_Mesa)
);

-- ---
-- Table 'Horario'
-- 
-- ---

DROP TABLE IF EXISTS HorarioSucursal4;
		
CREATE TABLE HorarioSucursal4 (
  id SERIAL,
  fecha DATE ,
  horaInicio TIME ,
  horaFin TIME ,
  id_Sucursal INT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Empleado_Horario'
-- 
-- ---

DROP TABLE IF EXISTS Empleado_HorarioSucursal4;
		
CREATE TABLE Empleado_HorarioSucursal4 (
  id_Empleado INT,
  id_Horario INT,
  PRIMARY KEY (id_Empleado, id_Horario)
);

-- ---
-- Table 'Persona'
-- 
-- ---

DROP TABLE IF EXISTS PersonaTZ;
		
CREATE TABLE PersonaTZ (
  nombres VARCHAR(60) ,
  apellPaterno VARCHAR(40) ,
  id SERIAL,
  apellMaterno VARCHAR(40) ,
  fechaNacimiento DATE ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Cuenta'
-- 
-- ---
--
DROP TABLE IF EXISTS CuentaTZ;
		
CREATE TABLE CuentaTZ (
  id VARCHAR(50),
  contrasenha VARCHAR(15) ,
  id_Persona INT ,
  id_RolCuenta INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Telefono'
-- 
-- ---
-- 
DROP TABLE IF EXISTS TelefonoTZ;
		
CREATE TABLE TelefonoTZ (
  numero VARCHAR(20),
  compania VARCHAR(20) ,
  id_Persona INT ,
  PRIMARY KEY (numero)
);

-- ---
-- Table 'Documento'
-- 
-- ---
-- 
DROP TABLE IF EXISTS DocumentoTZ;
		
CREATE TABLE DocumentoTZ (
  id VARCHAR(20),
  id_TipoDocumento INT ,
  id_Persona INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'ValeDescuento'
-- 
-- ---
-- TODO fragmentar segun su ID
DROP TABLE IF EXISTS ValeDescuentoFragmento;
		
CREATE TABLE ValeDescuentoFragmento (
  id SERIAL,
  stock INT ,
  descuento INT ,
  codigo INT ,
  id_Categoria INT ,
  PRIMARY KEY (id)
);

CREATE ROLE replicator WITH REPLICATION LOGIN PASSWORD '123456789';

CREATE PUBLICATION nodo4publication for ALL TABLES;
GRANT ALL PRIVILEGES ON DATABASE restaurantenodo4 TO replicator;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO replicator;

