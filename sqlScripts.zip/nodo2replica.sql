
-- ---
-- Table 'Producto'
-- 
-- ---

DROP TABLE IF EXISTS ProductoSucursal2;
		
CREATE TABLE ProductoSucursal2 (
  id SERIAL,
  nombre VARCHAR(50) ,
  precio FLOAT ,
  descrip TEXT ,
  disponible BOOL ,
  id_Categoria INT ,
  id_Sucursal INT ,
  imagen TEXT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Pedido'
-- 
-- ---

DROP TABLE IF EXISTS PedidoSucursal2;
		
CREATE TABLE PedidoSucursal2 (
  id SERIAL,
  fecha DATE ,
  hora TIME ,
  id_Empleado INT ,
  id_Persona INT ,
  consumoTotal FLOAT ,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  estado VARCHAR(50),
  PRIMARY KEY (id)
);

-- ---
-- Table 'LineaPedido'
-- 
-- ---
--
DROP TABLE IF EXISTS LineaPedidoSucursal2;
		
CREATE TABLE LineaPedidoSucursal2 (
  id SERIAL,
  id_Producto INT,
  id_Pedido INT,
  cantidad INT,
  PRIMARY KEY (id, id_Pedido)
);

-- ---
-- Table 'Empleado'
-- 
-- ---

DROP TABLE IF EXISTS EmpleadoSucursal2;
		
CREATE TABLE EmpleadoSucursal2 (
  id SERIAL,
  id_Persona INT ,
  horasSemana INT  ,
  id_RolEmpleado INT ,
  id_Sucursal INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Cliente'
-- 
-- ---
DROP TABLE IF EXISTS ClienteSucursal2;

CREATE TABLE ClienteSucursal2 (
  id SERIAL,
  id_Persona int,
  id_Sucursal int,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Mesa'
-- 
-- ---

DROP TABLE IF EXISTS MesaSucursal2;
		
CREATE TABLE MesaSucursal2 (
  id_Sucursal SERIAL,
  id INT,
  capacidad INT ,
  PRIMARY KEY (id, id_Sucursal)
);

-- ---
-- Table 'Reservacion'
-- 
-- ---

DROP TABLE IF EXISTS ReservacionSucursal2;
		
CREATE TABLE ReservacionSucursal2 (
  id SERIAL,
  fecha DATE,
  hora TIME,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  id_Persona INT ,
  PRIMARY KEY (id),
  UNIQUE (hora, fecha, id_Mesa, id_Sucursal_Mesa)
);

-- ---
-- Table 'Horario'
-- 
-- ---

DROP TABLE IF EXISTS HorarioSucursal2;
		
CREATE TABLE HorarioSucursal2 (
  id SERIAL,
  fecha DATE ,
  horaInicio TIME ,
  horaFin TIME ,
  id_Sucursal INT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Empleado_Horario'
-- 
-- ---

DROP TABLE IF EXISTS Empleado_HorarioSucursal2;
		
CREATE TABLE Empleado_HorarioSucursal2 (
  id_Empleado INT,
  id_Horario INT,
  PRIMARY KEY (id_Empleado, id_Horario)
);

-- ---
-- Table 'Persona'
-- 
-- ---

DROP TABLE IF EXISTS PersonaGL;
		
CREATE TABLE PersonaGL (
  nombres VARCHAR(60) ,
  apellPaterno VARCHAR(40) ,
  id SERIAL,
  apellMaterno VARCHAR(40) ,
  fechaNacimiento DATE ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Cuenta'
-- 
-- ---
--
DROP TABLE IF EXISTS CuentaGL;
		
CREATE TABLE CuentaGL (
  id VARCHAR(50),
  contrasenha VARCHAR(15) ,
  id_Persona INT ,
  id_RolCuenta INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Telefono'
-- 
-- ---
-- 
DROP TABLE IF EXISTS TelefonoGL;
		
CREATE TABLE TelefonoGL (
  numero VARCHAR(20),
  compania VARCHAR(20) ,
  id_Persona INT ,
  PRIMARY KEY (numero)
);

-- ---
-- Table 'Documento'
-- 
-- ---
-- 
DROP TABLE IF EXISTS DocumentoGL;
		
CREATE TABLE DocumentoGL (
  id VARCHAR(20),
  id_TipoDocumento INT ,
  id_Persona INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Sucursal'
--
-- ---
--
DROP TABLE IF EXISTS SucursalFragmento;
		
CREATE TABLE SucursalFragmento (
  id_Direccion INT,
  id SERIAL,
  aforo INT ,
  PRIMARY KEY (id),
  UNIQUE (id_Direccion)
);

-- ---
-- Table 'TipoDocumento'
-- 
-- ---
--TODO EN UN SOLO NODO /SIN FRAGMENTACION
DROP TABLE IF EXISTS TipoDocumentoFragmento;
		
CREATE TABLE TipoDocumentoFragmento (
  id SERIAL,
  descrip TEXT ,
  PRIMARY KEY (id)
);

CREATE SUBSCRIPTION nodo2subscription CONNECTION 'dbname=restaurantenodo2 host=25.29.134.65 port=5433 user=replicator password=123456789' PUBLICATION nodo2publication;


