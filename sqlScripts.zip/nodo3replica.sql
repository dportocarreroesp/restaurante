
-- ---
-- Table 'Producto'
-- 
-- ---

DROP TABLE IF EXISTS ProductoSucursal3;
		
CREATE TABLE ProductoSucursal3 (
  id SERIAL,
  nombre VARCHAR(50) ,
  precio FLOAT ,
  descrip TEXT ,
  disponible BOOL ,
  id_Categoria INT ,
  id_Sucursal INT ,
  imagen TEXT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Pedido'
-- 
-- ---

DROP TABLE IF EXISTS PedidoSucursal3;
		
CREATE TABLE PedidoSucursal3 (
  id SERIAL,
  fecha DATE ,
  hora TIME ,
  id_Empleado INT ,
  id_Persona INT ,
  consumoTotal FLOAT ,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  estado VARCHAR(50),
  PRIMARY KEY (id)
);

-- ---
-- Table 'LineaPedido'
-- 
-- ---
--
DROP TABLE IF EXISTS LineaPedidoSucursal3;
		
CREATE TABLE LineaPedidoSucursal3 (
  id SERIAL,
  id_Producto INT,
  id_Pedido INT,
  cantidad INT,
  PRIMARY KEY (id, id_Pedido)
);

-- ---
-- Table 'Empleado'
-- 
-- ---

DROP TABLE IF EXISTS EmpleadoSucursal3;
		
CREATE TABLE EmpleadoSucursal3 (
  id SERIAL,
  id_Persona INT ,
  horasSemana INT ,
  id_RolEmpleado INT ,
  id_Sucursal INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Cliente'
-- 
-- ---
DROP TABLE IF EXISTS ClienteSucursal3;

CREATE TABLE ClienteSucursal3 (
  id SERIAL,
  id_Persona int,
  id_Sucursal int,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Mesa'
-- 
-- ---

DROP TABLE IF EXISTS MesaSucursal3;
		
CREATE TABLE MesaSucursal3 (
  id_Sucursal SERIAL,
  id INT,
  capacidad INT ,
  PRIMARY KEY (id, id_Sucursal)
);

-- ---
-- Table 'Reservacion'
-- 
-- ---

DROP TABLE IF EXISTS ReservacionSucursal3;
		
CREATE TABLE ReservacionSucursal3 (
  id SERIAL,
  fecha DATE,
  hora TIME,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  id_Persona INT ,
  PRIMARY KEY (id),
  UNIQUE (hora, fecha, id_Mesa, id_Sucursal_Mesa)
);

-- ---
-- Table 'Horario'
-- 
-- ---

DROP TABLE IF EXISTS HorarioSucursal3;
		
CREATE TABLE HorarioSucursal3 (
  id SERIAL,
  fecha DATE ,
  horaInicio TIME ,
  horaFin TIME ,
  id_Sucursal INT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Empleado_Horario'
-- 
-- ---

DROP TABLE IF EXISTS Empleado_HorarioSucursal3;
		
CREATE TABLE Empleado_HorarioSucursal3 (
  id_Empleado INT,
  id_Horario INT,
  PRIMARY KEY (id_Empleado, id_Horario)
);

-- ---
-- Table 'Persona'
-- 
-- ---

DROP TABLE IF EXISTS PersonaMS;
		
CREATE TABLE PersonaMS (
  nombres VARCHAR(60) ,
  apellPaterno VARCHAR(40) ,
  id SERIAL,
  apellMaterno VARCHAR(40) ,
  fechaNacimiento DATE ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Cuenta'
-- 
-- ---
--
DROP TABLE IF EXISTS CuentaMS;
		
CREATE TABLE CuentaMS (
  id VARCHAR(50),
  contrasenha VARCHAR(15) ,
  id_Persona INT ,
  id_RolCuenta INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Telefono'
-- 
-- ---
-- 
DROP TABLE IF EXISTS TelefonoMS;
		
CREATE TABLE TelefonoMS (
  numero VARCHAR(20),
  compania VARCHAR(20) ,
  id_Persona INT ,
  PRIMARY KEY (numero)
);

-- ---
-- Table 'Documento'
-- 
-- ---
-- 
DROP TABLE IF EXISTS DocumentoMS;
		
CREATE TABLE DocumentoMS (
  id VARCHAR(20),
  id_TipoDocumento INT ,
  id_Persona INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'RolCuenta'
-- 
-- ---

DROP TABLE IF EXISTS RolCuentaFragmento;
		
CREATE TABLE RolCuentaFragmento (
  id SERIAL,
  nombre VARCHAR(20) ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Categoria'
-- 
-- ---

DROP TABLE IF EXISTS CategoriaFragmento;
		
CREATE TABLE CategoriaFragmento (
  id SERIAL,
  nombre VARCHAR(30) ,
  imagen TEXT,
  PRIMARY KEY (id)
);

CREATE SUBSCRIPTION nodo3subscription CONNECTION 'dbname=restaurantenodo3 host=25.29.134.33 user=replicator password=123456789' PUBLICATION nodo3publication;
