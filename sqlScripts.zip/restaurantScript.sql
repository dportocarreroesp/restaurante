-- ---
-- Globals
-- ---

-- SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
-- SET FOREIGN_KEY_CHECKS=0;

-- ---
-- Table 'Sucursal'
-- TODO
-- AGREGAR SERIAL RANGO EXPLICITO
-- ---
DROP TABLE IF EXISTS Sucursal;
		
CREATE TABLE Sucursal (
  id_Direccion INT  ,
  id SERIAL,
  aforo INT  ,
  PRIMARY KEY (id),
  UNIQUE (id_Direccion)
);

-- ---
-- Table 'Dirección'
-- 
-- ---

DROP TABLE IF EXISTS Direccion;
		
CREATE TABLE Direccion (
  id SERIAL,
  departamento VARCHAR(50),
  provincia VARCHAR(50) ,
  distrito VARCHAR  ,
  calle VARCHAR(50) ,
  numCalle INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Persona'
-- 
-- ---

DROP TABLE IF EXISTS Persona;
		
CREATE TABLE Persona (
  nombres VARCHAR(60) ,
  apellPaterno VARCHAR(40) ,
  id SERIAL,
  apellMaterno VARCHAR(40) ,
  fechaNacimiento DATE NULL ,
  PRIMARY KEY (id)
);
-- Table 'Cliente'
DROP TABLE IF EXISTS Cliente;

CREATE TABLE Cliente (
  id SERIAL,
  id_Persona int,
  id_Sucursal int,
  PRIMARY KEY (id),
  UNIQUE(id_Persona,id_Sucursal)
);
-- ---
-- Table 'TipoDocumento'
-- 
-- ---
--TODO EN UN SOLO NODO /SIN FRAGMENTACION
DROP TABLE IF EXISTS TipoDocumento;
		
CREATE TABLE TipoDocumento (
  id SERIAL,
  descrip TEXT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Documento'
-- 
-- ---
-- TODO junto a su respectiva persona
DROP TABLE IF EXISTS Documento;
		
CREATE TABLE Documento (
  id VARCHAR(20),
  id_TipoDocumento INT,
  id_Persona INT NULL ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Telefono'
-- 
-- ---
-- TODO junto a su respectiva persona
DROP TABLE IF EXISTS Telefono;
		
CREATE TABLE Telefono (
  numero VARCHAR(20),
  compania VARCHAR(20) ,
  id_Persona INT ,
  PRIMARY KEY (numero)
);

-- ---
-- Table 'Empleado'
-- 
-- ---

DROP TABLE IF EXISTS Empleado;
		
CREATE TABLE Empleado (
  id SERIAL,
  id_Persona INT,
  horasSemana INT ,
  id_RolEmpleado INT,
  id_Sucursal INT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Mesa'
-- 
-- ---

DROP TABLE IF EXISTS Mesa;
		
CREATE TABLE Mesa (
  id_Sucursal SERIAL,
  id INT,
  capacidad INT,
  PRIMARY KEY (id, id_Sucursal)
);

-- ---
-- Table 'Cuenta'
-- 
-- ---
--TODO con su persona respectiva
DROP TABLE IF EXISTS Cuenta;
		
CREATE TABLE Cuenta (
  id VARCHAR(50),
  contrasenha VARCHAR(15) ,
  id_Persona INT ,
  id_RolCuenta INT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'RolCuenta'
-- 
-- ---

DROP TABLE IF EXISTS RolCuenta;
		
CREATE TABLE RolCuenta (
  id SERIAL,
  nombre VARCHAR(20) ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Horario'
-- 
-- ---

DROP TABLE IF EXISTS Horario;
		
CREATE TABLE Horario (
  id SERIAL,
  fecha DATE,
  horaInicio TIME ,
  horaFin TIME ,
  id_Sucursal INT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Empleado_Horario'
-- 
-- ---

DROP TABLE IF EXISTS Empleado_Horario;
		
CREATE TABLE Empleado_Horario (
  id_Empleado INT,
  id_Horario INT,
  PRIMARY KEY (id_Empleado, id_Horario)
);

-- ---
-- Table 'RolEmpleado'
-- 
-- ---

DROP TABLE IF EXISTS RolEmpleado;
		
CREATE TABLE RolEmpleado (
  id SERIAL,
  rol VARCHAR(20) ,
  descrip TEXT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Pedido'
-- 
-- ---

DROP TABLE IF EXISTS Pedido;
		
CREATE TABLE Pedido (
  id SERIAL,
  fecha DATE ,
  hora TIME ,
  id_Empleado INT ,
  id_Persona INT ,
  consumoTotal FLOAT ,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  estado VARCHAR(50),
  PRIMARY KEY (id)
);

-- ---
-- Table 'LineaPedido'
-- 
-- ---
--TODO con su pedido respectivo
DROP TABLE IF EXISTS LineaPedido;
		
CREATE TABLE LineaPedido (
  id SERIAL,
  id_Producto INT,
  id_Pedido INT,
  cantidad INT,
  PRIMARY KEY (id, id_Pedido)
);

-- ---
-- Table 'Producto'
-- 
-- ---

DROP TABLE IF EXISTS Producto;
		
CREATE TABLE Producto (
  id SERIAL,
  nombre VARCHAR(50) ,
  precio FLOAT ,
  descrip TEXT ,
  disponible BOOL ,
  id_Categoria INT ,
  id_Sucursal INT ,
  imagen TEXT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Reservacion'
-- 
-- ---

DROP TABLE IF EXISTS Reservacion;
		
CREATE TABLE Reservacion (
  id SERIAL,
  fecha DATE,
  hora TIME,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  id_Persona INT ,
  PRIMARY KEY (id),
  UNIQUE (hora, fecha,id_Mesa,id_Sucursal_Mesa)
);

-- ---
-- Table 'ValeDescuento'
-- 
-- ---
-- TODO fragmentar segun su ID
DROP TABLE IF EXISTS ValeDescuento;
		
CREATE TABLE ValeDescuento (
  id SERIAL,
  stock INT ,
  descuento INT ,
  codigo INT,
  id_Categoria INT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Categoria'
-- 
-- ---

DROP TABLE IF EXISTS Categoria;
		
CREATE TABLE Categoria (
  id SERIAL,
  nombre VARCHAR(30) ,
  imagen TEXT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Insumo'
-- 
-- ---

DROP TABLE IF EXISTS Insumo;
		
CREATE TABLE Insumo (
  id SERIAL,
  nombre VARCHAR(30) ,
  unidadMedicion VARCHAR(10),
  cantidad INT,
  id_Sucursal INT ,
  id_Proveedor INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Proveedor'
-- 
-- ---

DROP TABLE IF EXISTS Proveedor;
		
CREATE TABLE Proveedor (
  id SERIAL,
  id_Persona INT ,
  PRIMARY KEY (id)
);

-- ---
-- Foreign Keys 
-- ---

ALTER TABLE Sucursal ADD FOREIGN KEY (id_Direccion) REFERENCES Direccion (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE Documento ADD FOREIGN KEY (id_TipoDocumento) REFERENCES TipoDocumento (id) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE Documento ADD FOREIGN KEY (id_Persona) REFERENCES Persona (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Telefono ADD FOREIGN KEY (id_Persona) REFERENCES Persona (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Empleado ADD FOREIGN KEY (id_Persona) REFERENCES Persona (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Empleado ADD FOREIGN KEY (id_RolEmpleado) REFERENCES RolEmpleado (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE Empleado ADD FOREIGN KEY (id_Sucursal) REFERENCES Sucursal (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE Mesa ADD FOREIGN KEY (id_Sucursal) REFERENCES Sucursal (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Cuenta ADD FOREIGN KEY (id_Persona) REFERENCES Persona (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Cuenta ADD FOREIGN KEY (id_RolCuenta) REFERENCES RolCuenta (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE Empleado_Horario ADD FOREIGN KEY (id_Empleado) REFERENCES Empleado (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE Empleado_Horario ADD FOREIGN KEY (id_Horario) REFERENCES Horario (id) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE Pedido ADD FOREIGN KEY (id_Empleado) REFERENCES Empleado (id) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE Pedido ADD FOREIGN KEY (id_Persona) REFERENCES Persona (id) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE Pedido ADD FOREIGN KEY (id_Mesa,id_Sucursal_Mesa) REFERENCES Mesa (id, id_Sucursal) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE LineaPedido ADD FOREIGN KEY (id_Producto) REFERENCES Producto (id) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE LineaPedido ADD FOREIGN KEY (id_Pedido) REFERENCES Pedido (id) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE Producto ADD FOREIGN KEY (id_Categoria) REFERENCES Categoria (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE Producto ADD FOREIGN KEY (id_Sucursal) REFERENCES Sucursal (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE Reservacion ADD FOREIGN KEY (id_Mesa, id_Sucursal_Mesa) REFERENCES Mesa (id, id_Sucursal) ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE Reservacion ADD FOREIGN KEY (id_Persona) REFERENCES Persona (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE ValeDescuento ADD FOREIGN KEY (id_Categoria) REFERENCES Categoria (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Insumo ADD FOREIGN KEY (id_Sucursal) REFERENCES Sucursal (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Insumo ADD FOREIGN KEY (id_Proveedor) REFERENCES Proveedor (id) ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE Proveedor ADD FOREIGN KEY (id_Persona) REFERENCES Persona (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Cliente ADD FOREIGN KEY (id_Sucursal) REFERENCES Sucursal(id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Cliente ADD FOREIGN KEY (id_Persona) REFERENCES Persona (id) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE Horario ADD FOREIGN KEY (id_Sucursal) REFERENCES Sucursal(id) ON DELETE CASCADE ON UPDATE CASCADE;
-- ---
-- Table Properties
-- ---

-- ALTER TABLE Sucursal ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Dirección ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Persona ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE TipoDocumento ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Documento ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Telefono ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Empleado ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Mesa ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Cuenta ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE RolCuenta ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Horario ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Empleado_Horario ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE RolEmpleado ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Pedido ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE LineaPedido ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Producto ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Reservacion ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE ValeDescuento ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Categoria ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Insumo ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
-- ALTER TABLE Proveedor ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ---
-- Test Data
-- ---

-- INSERT INTO Sucursal (id_Dirección,id,aforo) VALUES
-- ('','','');
-- INSERT INTO Dirección (id,departamento,provincia,distrito,calle,numCalle) VALUES
-- ('','','','','','');
-- INSERT INTO Persona (nombres,apellPaterno,id,apellMaterno,fechaNacimiento,correoElectronico) VALUES
-- ('','','','','','');
-- INSERT INTO TipoDocumento (id,descrip) VALUES
-- ('','');
-- INSERT INTO Documento (id,id_TipoDocumento,id_Persona) VALUES
-- ('','','');
-- INSERT INTO Telefono (numero,compania,id_Persona) VALUES
-- ('','','');
-- INSERT INTO Empleado (id,id_Persona,horasSemana,id_RolEmpleado,id_Sucursal) VALUES
-- ('','','','','');
-- INSERT INTO Mesa (id_Sucursal,id,capacidad) VALUES
-- ('','','');
-- INSERT INTO Cuenta (id,contrasenha,id_Persona,id_RolCuenta) VALUES
-- ('','','','');
-- INSERT INTO RolCuenta (id,nombre) VALUES
-- ('','');
-- INSERT INTO Horario (id,fecha,horaInicio,horaFin) VALUES
-- ('','','','');
-- INSERT INTO Empleado_Horario (id_Empleado,id_Horario) VALUES
-- ('','');
-- INSERT INTO RolEmpleado (id,rol,descrip) VALUES
-- ('','','');
-- INSERT INTO Pedido (id,fecha,hora,id_Empleado,id_Persona,consumoTotal,id_Mesa) VALUES
-- ('','','','','','','');
-- INSERT INTO LineaPedido (id,id_Producto,id_Pedido,cantidad) VALUES
-- ('','','','');
-- INSERT INTO Producto (id,nombre,precio,descrip,disponible,id_Categoria,id_Sucursal) VALUES
-- ('','','','','','','');
-- INSERT INTO Reservacion (id,fecha,hora,id_Mesa,id_Persona) VALUES
-- ('','','','','');
-- INSERT INTO ValeDescuento (id,stock,descuento,codigo,id_Categoria) VALUES
-- ('','','','','');
-- INSERT INTO Categoria (id,nombre) VALUES
-- ('','');
-- INSERT INTO Insumo (id,nombre,unidadMedicion,cantidad,id_Sucursal,id_Proveedor) VALUES
-- ('','','','','','');
-- INSERT INTO Proveedor (id,id_Persona) VALUES
-- ('','');
