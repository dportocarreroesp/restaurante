CREATE OR REPLACE FUNCTION CreateCuenta(id VARCHAR(20), contrasenha VARCHAR(15), id_persona int, id_rolcuenta int)
RETURNS void 
AS $$
BEGIN
	INSERT INTO cuenta(id, contrasenha, id_persona, id_rolcuenta) values (id, contrasenha, id_persona, id_rolcuenta);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateDireccion(depa VARCHAR(50),prov VARCHAR(50),dist VARCHAR(50),calle VARCHAR(50), numcalle int)
RETURNS void
AS $$
BEGIN
	INSERT INTO dirección(departamento,provincia,distrito,calle,numcalle) VALUES(depa,prov,dist,calle,numcalle);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateDocumento(id varchar(20),id_tipodocumento int, id_persona int)
RETURNS void
AS $$
BEGIN
	INSERT INTO documento(id, id_tipodocumento, id_persona) values(id, id_tipodocumento, id_persona);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateEmpleado(id_persona int, id_rolempleado int, inid_sucursal int)
RETURNS void
AS $$
BEGIN
	INSERT INTO empleado(id_persona, horassemana, id_rolempleado, id_sucursal) VALUES(id_persona, 0 , id_rolempleado, inid_sucursal);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateEmpleadoHorario(id_empleado int, id_horario int)
RETURNS void
AS $$
BEGIN
	INSERT INTO empleado_horario(id_empleado, id_horario) values (id_empleado, id_horario);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateHorario(fecha date, horainicio time, horafin time)
RETURNS void
AS $$
BEGIN
	INSERT INTO horario(fecha, horainicio, horafin) values (fecha, horainicio, horafin);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateInsumo(nombre varchar(30),unidadmedicion varchar(10), inid_sucursal int, id_proveedor int)
RETURNS void
AS $$
BEGIN
	INSERT INTO insumo(nombre, unidadmedicion, cantidad, id_sucursal, id_proveedor) values ( nombre, unidadmedicion, 0, inid_sucursal, id_proveedor);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateLineaPedido(id_producto int, id_pedido int, cantidad int)
RETURNS void
AS $$
BEGIN
	INSERT INTO lineapedido(id_producto, id_pedido, cantidad) values(id_producto, id_pedido, cantidad);
	UPDATE pedido SET consumototal = consumototal + cantidad*(select precio from producto where id = id_producto);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateMesa(inid_sucursal int, id int, capacidad int)
RETURNS void
AS $$
BEGIN
	INSERT INTO mesa(id_sucursal, id, capacidad) values (inid_sucursal, id, capacidad);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreatePersona(VARCHAR(60), VARCHAR(40),VARCHAR(40),DATE,VARCHAR(30))
RETURNS void
AS $$
BEGIN
	INSERT INTO Persona(nombres, apellpaterno, apellmaterno, fechanacimiento, correoelectronico) VALUES($1,$2,$3,$4,$5);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateProductoCategoria(nombre varchar(30))
RETURNS void
AS $$
BEGIN
	INSERT INTO categoria(nombre) values(nombre);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateProducto(nombre varchar(50), precio float, descrip text, id_categoria int, inid_sucursal int)
RETURNS void
AS $$
BEGIN
	INSERT INTO producto(nombre, precio, descrip, disponible, id_categoria, id_sucursal) values(nombre, precio, descrip, false, id_categoria, inid_sucursal);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateProveedor(id_persona int)
RETURNS void
AS $$
BEGIN
	INSERT INTO proveedor(id_persona) values (id_persona);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateReservacion(fecha date, hora time, id_mesa int, inid_sucursal_mesa int, id_persona int)
RETURNS void
AS $$
BEGIN
	INSERT INTO reservacion(fecha, hora, id_mesa, id_sucursal_mesa, id_persona) values (fecha, hora, id_mesa, inid_sucursal_mesa, id_persona );
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateRolCuenta(nombre VARCHAR(20))
RETURNS void
AS $$
BEGIN
	INSERT INTO rolcuenta(nombre) values(nombre);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateRolEmpleado(rol varchar(20), descrip text)
RETURNS void
AS $$
BEGIN
	INSERT INTO rolempleado(rol, descrip) VALUES(rol, descrip);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateSucursal(id_direccion int, aforo int)
RETURNS void
AS $$
BEGIN
	INSERT INTO Sucursal(id_dirección,aforo) VALUES(id_direccion, aforo);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateTelefono(numero VARCHAR(20), compania int, id_persona int)
RETURNS void
AS $$
BEGIN
	INSERT INTO telefono(numero,compania,id_persona) values(numero, compania, id_persona);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateTipoDocumento(descrip text)
RETURNS void
AS $$
BEGIN
	INSERT INTO tipodocumento(descrip) values(descrip);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateValeDescuento(stock int, descuento int, codigo int, id_categoria int)
RETURNS void
AS $$
BEGIN
	INSERT INTO valedescuento(stock, descuento, codigo, id_categoria) values (stock, descuento, codigo, id_categoria);
	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateAdministrador(nombres varchar(60),apellpaterno varchar(40), apellmaterno varchar(40), fechanacimiento date, tipodocumento int, documento varchar(20), correoelectronico varchar(30),contrasenha varchar(15), numero varchar(20), compania varchar(20), inid_sucursal int)
RETURNS void 
AS $$
DECLARE
	nuevapersonaid int;
BEGIN
	PERFORM nextval('persona_id_seq');
	SELECT currval(pg_get_serial_sequence('persona','id')) into nuevapersonaid;
	nuevapersonaid := nuevapersonaid+inid_sucursal*100000;
	insert into persona(nombres,apellpaterno,apellmaterno,fechanacimiento,id) values(nombres,apellpaterno,apellmaterno,fechanacimiento,nuevapersonaid);
	insert into documento(id,id_tipodocumento,id_persona)values(documento, tipodocumento,nuevapersonaid);
	insert into telefono(numero, compania, id_persona) values (numero, compania, nuevapersonaid);
	insert into empleado(id_persona,horassemana,id_rolempleado,id_sucursal)values(nuevapersonaid,0,3,inid_sucursal);
	insert into cuenta(id,contrasenha,id_persona,id_rolcuenta) values(correoelectronico,contrasenha,nuevapersonaid,3);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateMozo(nombres varchar(60),apellpaterno varchar(40), apellmaterno varchar(40), fechanacimiento date, tipodocumento int, documento varchar(20), correoelectronico varchar(30),contrasenha varchar(15), numero varchar(20), compania varchar(20), inid_sucursal integer)
RETURNS void 
AS $$
DECLARE
	nuevapersonaid integer;
BEGIN
	PERFORM nextval('persona_id_seq');
	SELECT currval(pg_get_serial_sequence('persona','id')) into nuevapersonaid;
	nuevapersonaid := nuevapersonaid+inid_sucursal*100000;
	insert into persona(nombres,apellpaterno,apellmaterno,fechanacimiento,id) values(nombres,apellpaterno,apellmaterno,fechanacimiento,nuevapersonaid);
	insert into documento(id,id_tipodocumento,id_persona)values(documento, tipodocumento, nuevapersonaid);
	insert into telefono(numero, compania, id_persona) values (numero, compania, nuevapersonaid);
	insert into empleado(id_persona,horassemana,id_rolempleado,id_sucursal)values(nuevapersonaid,0,1,inid_sucursal);
	insert into cuenta(id,contrasenha,id_persona,id_rolcuenta) values(correoelectronico,contrasenha,nuevapersonaid,1);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreateRecepcionista(nombres varchar(60),apellpaterno varchar(40), apellmaterno varchar(40), fechanacimiento date, tipodocumento int, documento varchar(20), correoelectronico varchar(30),contrasenha varchar(15), numero varchar(20), compania varchar(20), inid_sucursal int)
RETURNS void 
AS $$
DECLARE
	nuevapersonaid int;
BEGIN
	PERFORM nextval('persona_id_seq');
	SELECT currval(pg_get_serial_sequence('persona','id')) into nuevapersonaid;
	nuevapersonaid := nuevapersonaid+inid_sucursal*100000;
	insert into persona(nombres,apellpaterno,apellmaterno,fechanacimiento,id) values(nombres,apellpaterno,apellmaterno,fechanacimiento,nuevapersonaid);
	insert into documento(id,id_tipodocumento,id_persona)values(documento, tipodocumento, nuevapersonaid);
	insert into telefono(numero, compania, id_persona) values (numero, compania, nuevapersonaid);
	insert into empleado(id_persona,horassemana,id_rolempleado,id_sucursal)values(nuevapersonaid,0,2,inid_sucursal);
	insert into cuenta(id,contrasenha,id_persona,id_rolcuenta) values(correoelectronico,contrasenha,nuevapersonaid,2);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION ReadPedidos(correo varchar, fecha date)
RETURNS TABLE (id_mesa int, estado varchar )
AS $BODY$
DECLARE
	pedidoR record;
	idDuenhoPedidos int;
BEGIN
	SELECT id into idDuenhoPedidos from persona WHERE persona.correoelectronico = correo;
	SELECT id into idDuenhoPedidos from empleado WHERE empleado.id_persona = idDuenhoPedidos;
	FOR pedidoR IN(SELECT * FROM pedido WHERE id_empleado =idDuenhoPedidos ) LOOP
	id_mesa := pedidoR.id_mesa;
	estado := pedidoR.estado;
	RETURN NEXT;
	END LOOP;
END;
$BODY$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION IngresarSistema(correoelectronico varchar(30), contrasenha varchar(15))
RETURNS boolean 
AS $BODY$
DECLARE
	answer boolean;
BEGIN
	if (select cuenta.contrasenha from cuenta where id = correoelectronico) = contrasenha then
		answer := true;
	else
		answer := false;
	END IF;
	return answer;
END;
$BODY$ LANGUAGE plpgsql;



CREATE OR REPLACE FUNCTION CreateCliente(nombres varchar(60),apellpaterno varchar(40), apellmaterno varchar(40), fechanacimiento date, tipodocumento int, documento varchar(20), correoelectronico varchar(30),contrasenha varchar(15), numero varchar(20), compania varchar(20), inid_sucursal integer)
RETURNS void 
AS $$
DECLARE
	nuevapersonaid int;
BEGIN
	PERFORM nextval('persona_id_seq');
	SELECT currval(pg_get_serial_sequence('persona','id')) into nuevapersonaid;
	nuevapersonaid := nuevapersonaid+inid_sucursal*100000;
	insert into persona(nombres,apellpaterno,apellmaterno,fechanacimiento,id) values(nombres,apellpaterno,apellmaterno,fechanacimiento,nuevapersonaid);
	insert into documento(id,id_tipodocumento,id_persona)values(documento,tipodocumento,nuevapersonaid);
	insert into telefono(numero, compania, id_persona) values (numero, compania, nuevapersonaid);
	insert into cliente(id_persona,id_Sucursal)values(nuevapersonaid,inid_sucursal);
	insert into cuenta(id,contrasenha,id_persona,id_rolcuenta) values(correoelectronico,contrasenha,nuevapersonaid,4);
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION getProductos(idSucursal integer)
RETURNS TABLE (id integer, nombre varchar(50),precio double precision,
			   descrip text, disponible boolean, id_categoria integer,
			   id_sucursal integer, imagen text, nombreCategoria varchar(30))
AS $BODY$
DECLARE
	productoR record;
BEGIN
	FOR productoR IN(
		SELECT p.id, p.nombre, p.precio, p.descrip, p.disponible, 
		p.id_categoria, p.id_sucursal, p.imagen, c.nombre AS "categoria"
		FROM producto p inner join 
		categoria c on p.id_categoria = c.id where p.id_sucursal = idSucursal) 
		LOOP
		id := productoR.id;
		nombre := productoR.nombre;
		precio := productoR.precio;
		descrip := productoR.descrip;
		disponible := productoR.disponible;
		id_categoria := productoR.id_categoria;
		id_sucursal := productoR.id_sucursal;
		imagen := productoR.imagen;
		nombreCategoria := productoR.categoria;
		RETURN NEXT;
	END LOOP;
END;
$BODY$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION CreatePedido(fecha date, hora time, correo_empleado varchar(50), correo_cliente varchar(50), id_mesa int, inid_sucursal_mesa int)
RETURNS int
AS $BODY$
DECLARE
	idnuevopedido int;
	idnuevoreservacion int;
	id_empleado int;
	id_cliente int;
BEGIN
	SELECT id_persona INTO id_empleado FROM cuenta where id = correo_empleado; 
	SELECT id_persona INTO id_cliente FROM cuenta where id = correo_cliente;
		
	PERFORM nextval('reservacion_id_seq');
	SELECT currval(pg_get_serial_sequence('reservacion','id')) into idnuevoreservacion;
	idnuevoreservacion := idnuevoreservacion+inid_sucursal_mesa*100000;
	
   	INSERT INTO reservacion(fecha,hora,id_mesa,id_sucursal_mesa,id_persona,id) values (fecha,hora,id_mesa,inid_sucursal_mesa,id_cliente,idnuevoreservacion);
	
	PERFORM nextval('pedido_id_seq');
	SELECT currval(pg_get_serial_sequence('pedido','id')) into idnuevopedido;		
	idnuevopedido := idnuevopedido+inid_sucursal_mesa*100000;	
	
	INSERT INTO pedido(fecha,hora,id_empleado,id_persona,consumototal,id_mesa,id_sucursal_mesa,estado,id) values(fecha, hora, id_empleado, id_cliente, 0, id_mesa, inid_sucursal_mesa,'Activo',idnuevopedido);
	return idnuevopedido;
END;
$BODY$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION getPedidos(idSucursal integer)
RETURNS TABLE (id integer, fecha date, hora time, id_empleado integer, id_persona integer, consumototal double precision,
			   id_mesa integer, id_sucursal_mesa integer, estado varchar(50))
AS $BODY$
DECLARE
	pedidoR record;
BEGIN
	FOR pedidoR IN(
		SELECT p.id, p.fecha, p.hora, p.id_empleado, p.id_persona, 
		p.consumototal, p.id_mesa, p.id_sucursal_mesa, p.estado
		FROM pedido p where p.estado LIKE 'A%' and p.id_sucursal_mesa = idSucursal) 
	LOOP	
		id := pedidoR.id;
		fecha := pedidoR.fecha;
		hora := pedidoR.hora;
		id_empleado := pedidoR.id_empleado;
		id_persona := pedidoR.id_persona;
		consumototal := pedidoR.consumototal;
		id_mesa := pedidoR.id_mesa;
		id_sucursal_mesa := pedidoR.id_sucursal_mesa;
		estado := pedidoR.estado;
		RETURN NEXT;
	END LOOP;
END;
$BODY$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION getMesasDisponibles(inFecha date, inHora time, inSucursal int)
RETURNS TABLE (outIdMesa int)
AS $BODY$
DECLARE
	mesasR record;
BEGIN
	FOR mesasR IN(
		select * from mesa where id_sucursal = inSucursal and id not in(
		select id_mesa from reservacion where fecha = inFecha 
		and id_Sucursal_mesa = inSucursal and
		((hora >inHora and hora <=(inHora +'01:00' ))or(hora >=(inHora-'01:00') and hora <=inHora )))
	
	)
	LOOP
		outIdMesa := mesasR.id;
		RETURN NEXT;
	END LOOP;

END;
$BODY$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION deletePedido(idSucursal integer, idPedido integer)
RETURNS integer
AS $BODY$
DECLARE
	fechaR date;
	horaR time;
BEGIN
	SELECT fecha into fechaR from pedido where id_sucursal_mesa = idSucursal and id = idPedido;
	SELECT hora into horaR from pedido where id_sucursal_mesa = idSucursal and id = idPedido;
	DELETE FROM pedido where id_sucursal_mesa = idSucursal and id = idPedido;
	DELETE FROM reservacion where id_sucursal_mesa = idSucursal and fecha = fechaR and hora = horaR;
	if not found then
		return 0;
	else
		return 1;
	end if;
END;
$BODY$ LANGUAGE plpgsql;
