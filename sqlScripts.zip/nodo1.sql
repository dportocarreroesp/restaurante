-- ---
-- Table 'Producto'
-- 
-- ---

DROP TABLE IF EXISTS ProductoSucursal1;
		
CREATE TABLE ProductoSucursal1 (
  id SERIAL,
  nombre VARCHAR(50) ,
  precio FLOAT ,
  descrip TEXT ,
  disponible BOOL ,
  id_Categoria INT ,
  id_Sucursal INT ,
  imagen TEXT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Pedido'
-- 
-- ---

DROP TABLE IF EXISTS PedidoSucursal1;
		
CREATE TABLE PedidoSucursal1 (
  id SERIAL,
  fecha DATE ,
  hora TIME ,
  id_Empleado INT ,
  id_Persona INT ,
  consumoTotal FLOAT ,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  estado VARCHAR(50),
  PRIMARY KEY (id)
);

-- ---
-- Table 'LineaPedido'
-- 
-- ---
--
DROP TABLE IF EXISTS LineaPedidoSucursal1;
		
CREATE TABLE LineaPedidoSucursal1 (
  id SERIAL,
  id_Producto INT,
  id_Pedido INT,
  cantidad INT,
  PRIMARY KEY (id, id_Pedido)
);

-- ---
-- Table 'Empleado'
-- 
-- ---

DROP TABLE IF EXISTS EmpleadoSucursal1;
		
CREATE TABLE EmpleadoSucursal1 (
  id SERIAL,
  id_Persona INT ,
  horasSemana INT ,
  id_RolEmpleado INT ,
  id_Sucursal INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Cliente'
-- 
-- ---
DROP TABLE IF EXISTS ClienteSucursal1;

CREATE TABLE ClienteSucursal1 (
  id SERIAL,
  id_Persona int,
  id_Sucursal int,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Mesa'
-- 
-- ---

DROP TABLE IF EXISTS MesaSucursal1;
		
CREATE TABLE MesaSucursal1 (
  id_Sucursal SERIAL,
  id INT,
  capacidad INT ,
  PRIMARY KEY (id, id_Sucursal)
);

-- ---
-- Table 'Reservacion'
-- 
-- ---

DROP TABLE IF EXISTS ReservacionSucursal1;
		
CREATE TABLE ReservacionSucursal1 (
  id SERIAL,
  fecha DATE,
  hora TIME,
  id_Mesa INT,
  id_Sucursal_Mesa SERIAL,
  id_Persona INT ,
  PRIMARY KEY (id),
  UNIQUE (hora, fecha, id_Mesa, id_Sucursal_Mesa)
);

-- ---
-- Table 'Horario'
-- 
-- ---

DROP TABLE IF EXISTS HorarioSucursal1;
		
CREATE TABLE HorarioSucursal1 (
  id SERIAL,
  fecha DATE ,
  horaInicio TIME ,
  horaFin TIME ,
  id_Sucursal INT,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Empleado_Horario'
-- 
-- ---

DROP TABLE IF EXISTS Empleado_HorarioSucursal1;
		
CREATE TABLE Empleado_HorarioSucursal1 (
  id_Empleado INT,
  id_Horario INT,
  PRIMARY KEY (id_Empleado, id_Horario)
);

-- ---
-- Table 'Persona'
-- 
-- ---

DROP TABLE IF EXISTS PersonaAF;
		
CREATE TABLE PersonaAF (
  nombres VARCHAR(60) ,
  apellPaterno VARCHAR(40) ,
  id SERIAL,
  apellMaterno VARCHAR(40) ,
  fechaNacimiento DATE ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Cuenta'
-- 
-- ---
--
DROP TABLE IF EXISTS CuentaAF;
		
CREATE TABLE CuentaAF (
  id VARCHAR(50),
  contrasenha VARCHAR(15) ,
  id_Persona INT ,
  id_RolCuenta INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Telefono'
-- 
-- ---
-- 
DROP TABLE IF EXISTS TelefonoAF;
		
CREATE TABLE TelefonoAF (
  numero VARCHAR(20),
  compania VARCHAR(20) ,
  id_Persona INT ,
  PRIMARY KEY (numero)
);

-- ---
-- Table 'Documento'
-- 
-- ---
-- 
DROP TABLE IF EXISTS DocumentoAF;
		
CREATE TABLE DocumentoAF (
  id VARCHAR(20),
  id_TipoDocumento INT ,
  id_Persona INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'Dirección'
-- 
-- ---

DROP TABLE IF EXISTS DireccionFragmento;
		
CREATE TABLE DireccionFragmento (
  id SERIAL,
  departamento VARCHAR(50) ,
  provincia VARCHAR(50) ,
  distrito VARCHAR ,
  calle VARCHAR(50) ,
  numCalle INT ,
  PRIMARY KEY (id)
);

-- ---
-- Table 'RolEmpleado'
-- 
-- ---

DROP TABLE IF EXISTS RolEmpleadoFragmento;
		
CREATE TABLE RolEmpleadoFragmento (
  id SERIAL,
  rol VARCHAR(20) ,
  descrip TEXT ,
  PRIMARY KEY (id)
);

CREATE ROLE replicator WITH REPLICATION LOGIN PASSWORD '123456789';

CREATE PUBLICATION nodo1publication for ALL TABLES;
GRANT ALL PRIVILEGES ON DATABASE restaurantenodo1 TO replicator;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO replicator;
